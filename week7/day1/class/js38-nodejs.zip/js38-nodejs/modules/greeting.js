const greeting = function(name) {
  console.log(`Hello ${name}, welcome to NodeJs class`);
}

const hello = (name) => {
  console.log('Hello '+ name);
}

const a = 'aaa';

module.exports = {
  greeting,
  hello,
  a,
}
